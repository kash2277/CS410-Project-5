#pragma once

#define ROOT_DOMAIN "root.atsign.org"
#define ROOT_PORT 64
