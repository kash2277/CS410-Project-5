// constants.h

#pragma once

#define SSID "NETGEAR"
#define PASSWORD "thirstysun490"